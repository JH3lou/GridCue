# Claude repository entry point

Read and follow `AGENTS.md` first. It is the canonical repository instruction file.

If the repository has not yet been scaffolded, execute only the work order in `BUILD_AGENT.md`. Otherwise use the context-routing table in `AGENTS.md` and load only the documents relevant to the current task.
